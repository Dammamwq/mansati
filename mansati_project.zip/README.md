# منصّتي — منصة خدمات متكاملة (Scaffold)
مشروع MVP متكامل باستخدام: Next.js (TypeScript) + TailwindCSS + Express (TypeScript) + Prisma + PostgreSQL + Socket.io + Stripe + Docker.
الواجهة افتراضية بالعربية مع دعم الإنجليزية.

## ملاحظات مهمة
- هذا scaffold يحتوي على بنية جاهزة للعمل: واجهات، API، محادثات بالـ Socket.io، رفع صور محليًا، Prisma schema، وملفات Docker.
- بعد تحميل الملف، اتبع التعليمات أدناه لتشغيل المشروع محليًا.

## تشغيل سريع (مطلوب: Docker & Docker Compose)
1. فك ضغط الحزمة.
2. انسخ `.env.example` إلى `.env` لكل من `backend/` و`frontend/` وقم بتعديل القيم (خاصة مفاتيح Stripe والـ DATABASE_URL إذا لزم).
3. شغّل:
```bash
docker-compose up --build
```
4. افتح الواجهة: http://localhost:3000
   - API: http://localhost:4000/api/v1
   - Socket.io server يعمل على نفس backend

## تشغيل محلي بدون Docker (اختياري)
- ستحتاج Node.js وpnpm/npm، وPostgreSQL محلي.
- انتقل إلى المجلدين `backend` و`frontend` واتبع README داخل كل واحد.

## ملاحظة عن Prisma
- بعد تشغيل قاعدة البيانات، من داخل مجلد `backend` شغّل:
```bash
npx prisma generate
npx prisma migrate dev --name init
```
- ثم ابدأ السيرفر.

## محتوى الحزمة
- backend/: Express + TypeScript + Prisma + Socket.io
- frontend/: Next.js + TypeScript + Tailwind + Socket.io-client
- docker-compose.yml
- .env.example files
