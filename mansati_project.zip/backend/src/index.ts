import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import http from 'http';
import cors from 'cors';
import { Server as IoServer } from 'socket.io';
import { PrismaClient } from '@prisma/client';
import authRouter from './routes/auth';
import servicesRouter from './routes/services';
import ordersRouter from './routes/orders';
import messagesRouter from './routes/messages';
import paymentsRouter from './routes/payments';
import adminRouter from './routes/admin';
import path from 'path';
import fs from 'fs';

const app = express();
const server = http.createServer(app);
const io = new IoServer(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

const prisma = new PrismaClient();
app.locals.prisma = prisma;

// ensure uploads dir exists
const uploadsDir = process.env.UPLOADS_DIR || './uploads';
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(path.resolve(uploadsDir)));

// mount routes
app.use('/api/v1/auth', authRouter);
app.use('/api/v1/services', servicesRouter);
app.use('/api/v1/orders', ordersRouter);
app.use('/api/v1/messages', messagesRouter);
app.use('/api/v1/payments', paymentsRouter);
app.use('/api/v1/admin', adminRouter);

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('joinOrderRoom', (orderId) => {
    socket.join(orderId);
  });
  socket.on('leaveOrderRoom', (orderId) => {
    socket.leave(orderId);
  });
  socket.on('sendMessage', async (data) => {
    // data: { orderId, senderId, text }
    try {
      const prisma: any = app.locals.prisma;
      const msg = await prisma.message.create({
        data: {
          orderId: data.orderId,
          senderId: data.senderId,
          text: data.text
        }
      });
      io.to(data.orderId).emit('newMessage', msg);
    } catch (err) {
      console.error('sendMessage error', err);
    }
  });
});

const port = process.env.PORT || 4000;
server.listen(port, () => {
  console.log(`Backend listening on ${port}`);
});
