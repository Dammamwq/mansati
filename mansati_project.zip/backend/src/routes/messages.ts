import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

router.get('/order/:orderId', async (req, res) => {
  const msgs = await prisma.message.findMany({ where: { orderId: req.params.orderId }, orderBy: { createdAt: 'asc' } });
  res.json({ messages: msgs });
});

export default router;
