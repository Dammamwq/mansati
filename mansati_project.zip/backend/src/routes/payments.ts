import { Router } from 'express';
import Stripe from 'stripe';
const router = Router();
const stripe = new Stripe(process.env.STRIPE_SECRET || 'sk_test_key', { apiVersion: '2024-11-15' });

router.post('/create-intent', async (req, res) => {
  const { amount, currency = 'usd' } = req.body;
  try {
    const intent = await stripe.paymentIntents.create({
      amount: Math.round(Number(amount) * 100),
      currency
    });
    res.json({ clientSecret: intent.client_secret });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'stripe_error' });
  }
});

export default router;
