import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

// Note: In real app protect with JWT & admin check
router.get('/users', async (req, res) => {
  const users = await prisma.user.findMany();
  res.json({ users });
});

router.get('/services', async (req, res) => {
  const services = await prisma.service.findMany();
  res.json({ services });
});

export default router;
