import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

router.post('/', async (req, res) => {
  const { serviceId, buyerId } = req.body;
  const service = await prisma.service.findUnique({ where: { id: serviceId } });
  if (!service) return res.status(404).json({ error: 'service_not_found' });
  const order = await prisma.order.create({
    data: {
      serviceId: service.id,
      buyerId,
      sellerId: service.sellerId,
      amount: service.price
    }
  });
  res.json({ order });
});

router.get('/:id', async (req, res) => {
  const order = await prisma.order.findUnique({ where: { id: req.params.id }, include: { messages: true } });
  if (!order) return res.status(404).json({ error: 'not_found' });
  res.json({ order });
});

export default router;
