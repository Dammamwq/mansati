import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import { PrismaClient } from '@prisma/client';
import fs from 'fs';

const router = Router();
const prisma = new PrismaClient();

const uploadDir = process.env.UPLOADS_DIR || './uploads/services';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.random().toString(36).slice(2) + ext);
  }
});
const upload = multer({ storage });

router.get('/', async (req, res) => {
  const q = (req.query.q as string) || '';
  const items = await prisma.service.findMany({
    where: { title: { contains: q, mode: 'insensitive' } },
    take: 50
  });
  res.json({ items });
});

router.post('/', upload.array('images', 5), async (req, res) => {
  const { sellerId, title, description, price, deliveryDays } = req.body;
  const images = (req.files as Express.Multer.File[]).map(f => '/uploads/services/' + path.basename(f.path));
  const service = await prisma.service.create({
    data: {
      sellerId: sellerId,
      title,
      description,
      price: parseFloat(price),
      deliveryDays: parseInt(deliveryDays || '3'),
      images
    }
  });
  res.json({ service });
});

export default router;
