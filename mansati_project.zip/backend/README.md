# backend (Express + TypeScript + Prisma)

## Setup (without Docker)
1. Install dependencies: `pnpm install` (or `npm install`)
2. Copy `.env.example` to `.env` and adjust.
3. Generate Prisma client: `npx prisma generate`
4. Run migrations: `npx prisma migrate dev --name init`
5. Start dev server: `pnpm run dev`

## Notes
- Uploads stored under the `uploads/` folder (configured by UPLOADS_DIR).
- Socket.io is integrated in `src/index.ts`. Use `joinOrderRoom` event to join.
