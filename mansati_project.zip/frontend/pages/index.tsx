import useSWR from 'swr'
import axios from 'axios'
import Link from 'next/link'
const fetcher = (u:string)=>axios.get(u).then(r=>r.data);

export default function Home(){ 
  const { data } = useSWR(process.env.NEXT_PUBLIC_API_URL + '/services', fetcher);
  const items = data?.items || [];
  return (<div className="p-8" dir="rtl">
    <header className="flex justify-between items-center">
      <h1 className="text-2xl font-bold">منصّتي</h1>
      <nav><Link href="/en"><a>English</a></Link></nav>
    </header>
    <main className="mt-6">
      <h2 className="text-xl">الخدمات</h2>
      <div className="grid grid-cols-3 gap-4 mt-4">
        {items.map((it:any)=>(
          <div key={it.id} className="p-4 border rounded">
            <h3 className="font-bold">{it.title}</h3>
            <p className="text-sm">{it.description}</p>
            <div className="mt-2">{it.price} USD</div>
            <div className="mt-2"><Link href={`/service/${it.id}`}><a className="text-blue-600">عرض الخدمة</a></Link></div>
          </div>
        ))}
      </div>
    </main>
  </div>)
}
