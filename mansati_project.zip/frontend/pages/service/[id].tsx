import { useRouter } from 'next/router'
import useSWR from 'swr'
import axios from 'axios'
import Link from 'next/link'
const fetcher = (u:string)=>axios.get(u).then(r=>r.data);

export default function ServicePage(){
  const router = useRouter();
  const { id } = router.query;
  const { data } = useSWR(id ? process.env.NEXT_PUBLIC_API_URL + '/services?q=' + id : null, fetcher);
  const service = data?.items?.[0];
  if(!service) return <div className="p-8">خدمة غير موجودة</div>;
  return (<div className="p-8" dir="rtl">
    <h1 className="text-2xl">{service.title}</h1>
    <p className="mt-2">{service.description}</p>
    <div className="mt-4">السعر: {service.price} USD</div>
    <div className="mt-4"><Link href="/chat/[id]" as={`/chat/${service.id}`}><a className="px-3 py-2 bg-blue-600 text-white rounded">محادثة حول الخدمة</a></Link></div>
  </div>)
}
