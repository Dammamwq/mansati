import { useRouter } from 'next/router'
import { useEffect, useState, useRef } from 'react'
import io from 'socket.io-client'
import axios from 'axios'

export default function ChatPage(){
  const router = useRouter();
  const { id } = router.query; // use orderId or serviceId depending on flow
  const [socket, setSocket] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState('');
  const messagesRef = useRef<HTMLDivElement>(null);

  useEffect(()=>{
    if(!id) return;
    const s = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:4000');
    setSocket(s);
    s.emit('joinOrderRoom', id);
    s.on('newMessage', (msg:any)=> setMessages(prev=>[...prev, msg]));
    return ()=> { s.emit('leaveOrderRoom', id); s.disconnect(); }
  },[id]);

  useEffect(()=>{ if(messagesRef.current) messagesRef.current.scrollTop = messagesRef.current.scrollHeight; },[messages]);

  const send = ()=>{
    if(!socket) return;
    socket.emit('sendMessage', { orderId: id, senderId: 'SYSTEM', text });
    setText('');
  }

  return (<div className="p-8" dir="rtl">
    <h2 className="text-xl">محادثة</h2>
    <div ref={messagesRef} className="mt-4 h-96 overflow-auto border p-4">
      {messages.map(m=>(<div key={m.id} className="mb-2"><strong>{m.senderId}</strong>: {m.text}</div>))}
    </div>
    <div className="mt-4 flex gap-2">
      <input value={text} onChange={e=>setText(e.target.value)} className="flex-1 p-2 border" />
      <button onClick={send} className="px-4 py-2 bg-blue-600 text-white rounded">إرسال</button>
    </div>
  </div>)
}
