# frontend (Next.js + TypeScript + Tailwind)

## Run locally (without Docker)
1. pnpm install
2. copy .env.example to .env
3. pnpm run dev
