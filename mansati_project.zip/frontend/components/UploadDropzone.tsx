import { useCallback, useState } from 'react'
import axios from 'axios'

export default function UploadDropzone({ onUploaded }: any) {
  const [files, setFiles] = useState<File[]>([]);
  const onChange = useCallback((e:any)=> setFiles(Array.from(e.target.files)), []);

  const upload = async ()=>{
    const fd = new FormData();
    files.forEach(f=> fd.append('images', f));
    // sellerId should be included in real app (from auth)
    fd.append('sellerId', 'placeholder-seller-id');
    const res = await axios.post(process.env.NEXT_PUBLIC_API_URL + '/services', fd, { headers: {'Content-Type':'multipart/form-data'} });
    onUploaded(res.data.service);
  };

  return (<div className="p-4 border rounded">
    <label className="block mb-2">اسحب وأسقط الملفات أو اخترها</label>
    <input type="file" multiple onChange={onChange} />
    <div className="mt-2 flex gap-2">
      <button onClick={upload} className="px-3 py-2 bg-green-600 text-white rounded">رفع</button>
    </div>
  </div>)
}
